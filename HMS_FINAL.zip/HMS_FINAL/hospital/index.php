<?php
include_once('hms/include/config.php');
if(isset($_POST['submit']))
{
$name=$_POST['fullname'];
$email=$_POST['emailid'];
$mobileno=$_POST['mobileno'];
$dscrption=$_POST['description'];
$query=mysqli_query($con,"insert into tblcontactus(fullname,email,contactno,message) value('$name','$email','$mobileno','$dscrption')");
echo "<script>alert('Your information succesfully submitted');</script>";
echo "<script>window.location.href ='index.php'</script>";

} ?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title> Hospital management System </title>

    <link rel="shortcut icon" href="assets/images/fav.jpg">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/fontawsom-all.min.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3pro.css">
    <link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-black.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css" />

    <style>


    </style>
</head>

<body>

    <!-- ################# Header Starts Here#######################--->
    <header class="w3-container w3-theme w3-padding-22" id="myHeader">
        <div class="w3-center">
            <h1 class="w3-xxxlarge w3-animate-bottom">HOSPITAL MANAGEMENT SYSTEM</h1>
        </div>
    </header>
    
    <header id="menu-jk" >
    
        <div id="nav-head" class="header-nav" style="background-color:aliceblue;">
            <div class="container">
                <div class="row">
                    
                    <div class="col-lg-1 col-md-3  col-sm-12" style="font-weight:bold; font-size:42px; margin-top: 1%;">
                        <i class="fa fa-diamond w3-margin-bottom w3-text-theme" style="font: size 42px;"></i>
                       <a data-toggle="collapse" data-target="#menu" href="#menu" ><i class="fas d-block d-md-none small-menu fa-bars"></i></a>
                    </div>
                    
                    <div id="menu" class="col-lg-10 col-md-9 d-none d-md-block nav-item" style="font-weight:bold; font-size:42px;">
                        <ul>
                            <li><a href="#">Home</a></li>
                            <li><a href="#specialities">Specialities</a></li>
                            <li><a href="#logins">Logins</a></li>  
                            <li><a href="#about_us">About Us</a></li>
                            <li><a href="#contact_us">Contact Us</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-1 d-none d-lg-block appoint">
                        <a class="btn btn-success" style="background-color: rgba(45, 145, 158, 0.53);" href="hms/user_login.php">Book an Appointment</a>
                    </div>
                </div>

            </div>
        </div>
    </header>

    
    <div class="container">
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
    
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
        
        <div class="item active">
            <img class="d-block w-100" src="assets/images/digital.jpg" alt="Third slide" style="width:200px;height:600px;">
            <div class="carousel-cover"></div>
            <div class="carousel-caption vdg-cur d-none d-md-block">
                <h3 class="animated bounceInDown">Digital Imaging And Diagnostics Management</h3>
            </div>
        </div>

        <div class="item">
            <img class="d-block w-100" src="assets/images/vital.jpg" alt="First slide" style="width:200px;height:600px;">
            <div class="carousel-caption vdg-cur d-none d-md-block">
                <h3 class="animated bounceInDown">Vital Tracking And Management</h3>
            </div>
        </div>

        <div class="item">
            <img class="d-block w-100" src="assets/images/pharmacy.jpg" alt="Second slide" style="width:200px;height:600px;">
            <div class="carousel-caption vdg-cur d-none d-md-block">
                <h3 class="animated bounceInDown">Pharmacy And Store Management</h3>
            </div>
        </div>
    
        
    </div>

        <!-- Left and right controls -->
        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right"></span>
            <span class="sr-only">Next</span>
        </a>
        </div>
    </div>




    <!--  ************************* Logins ************************** -->
    
    
    <section id="logins" class="our-blog container-fluid" style="background-color:aliceblue;">
        
        <div class="w3-row-padding w3-center w3-margin-top" style="background-color:aliceblue;">
            <div class="row" >

                <div class="column">
                    <div class="card" style="background-color:white;">
                        <h3>Frontdesk Operator Login</h3><br>
                        <!--i class="fa fa-desktop w3-margin-bottom w3-text-theme" style="font-size:120px"></i-->
                        <img src="assets/images/fdo1.jpg" alt="" style="width:500px;height:350px; ">
                            <div class="blog-single-det" style="width:100%; background-color:#fff;padding:25px;">
                                <a href="hms/user_login.php" target="_blank">
                                    <button class="btn btn-success btn-sm" style="background-color:#83ccc7;">Click Here</button>
                                </a>
                            </div>
                    </div>
                </div>

                <div class="column">
                    <div class="card" style="background-color:white;">
                        <h3>Data-Entry Operator Login</h3><br>
                        <!--i class="fa fa-desktop w3-margin-bottom w3-text-theme" style="font-size:120px"></i-->
                        <img src="assets/images/deo.jpg" alt="" style="width:500px;height:350px; ">
                        <div class="blog-single-det" style="width:100%; background-color:#fff;padding:25px;">
                            <a href="hms/user_login.php" target="_blank">
                                <button class="btn btn-success btn-sm" style="background-color:#83ccc7;">Click Here</button>
                            </a>
                        </div>
                        
                    </div>
                </div>

                <div class="column">
                    <div class="card" style="background-color:white;">
                        <h3>Doctors login</h3><br>
                        <!--i class="fa fa-css3 w3-margin-bottom w3-text-theme" style="font-size:120px"></i-->
                        <img src="assets/images/doctorlogo1.webp" alt="" style="width:500px;height:350px;">
                        <div class="blog-single-det" style="width:100%; background-color:#fff;padding:25px;">
                            <a href="hms/doctor" target="_blank">
                                <button class="btn btn-success btn-sm" style="background-color:#83ccc7;">Click Here</button>
                            </a>
                        </div>
                    </div>
                </div>

                <div class="column">
                    <div class="card" style="background-color:white;">
                        <h3>Admin Login</h3><br>
                        <!--i class="fa fa-diamond w3-margin-bottom w3-text-theme" style="font-size:120px"></i-->
                        <img src="assets/images/adminpaapa.jpg" alt="" style="width:500px;height:350px;">           
                        <div class="blog-single-det" style="width:100%; background-color:#fff;padding:25px;">
                            <a href="hms/admin" target="_blank">
                                <button class="btn btn-success btn-sm" style="background-color:#83ccc7;">Click Here</button>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>  

                            
                            
    </section>
    
      


    
     <!-- ################# Specialities Starts Here#######################-->
     <h2 class="w3-center">Specialities</h2>
     <section id="specialities" class="Specialities department" style="background-color:aliceblue;">
    
    <div class="w3-content w3-display-container" style="width: 100%; height: 500px; margin: 0px 200px 200px 200px;">

        <img class="mySlides w3-animate-opacity" src="assets/images/cardiology.jpg" style="width:100%; height: 100%;">
        <img class="mySlides w3-animate-opacity" src="assets/images/dental.jpg" style="width:100%; height: 100%;">
        <img class="mySlides w3-animate-opacity" src="assets/images/pediatrician.jpg" style="width:100%; height: 100%;">

        <a class="w3-button w3-theme w3-display-left" style="background-color:aliceblue;" onclick="plusDivs(-1)">❮</a>
        <a class="w3-button w3-theme w3-display-right" style="background-color:aliceblue;" onclick="plusDivs(+1)">❯</a>
    </div>

    <!--div class="row">
        <div class="column">
            <img src="assets/images/slider/slider_1.jpg" onclick="openModal();currentSlide(1)" class="hover-shadow">
        </div>
        <div class="column">
            <img src="assets/images/slider/slider_1.jpg" onclick="openModal();currentSlide(2)" class="hover-shadow">
        </div>
        <div class="column">
            <img src="assets/images/slider/slider_1.jpg" onclick="openModal();currentSlide(3)" class="hover-shadow">
        </div>
        <div class="column">
            <img src="assets/images/slider/slider_1.jpg" onclick="openModal();currentSlide(4)" class="hover-shadow">
        </div>
    </div>

<!-- The Modal/Lightbox >
<div id="myModal" class="modal">
  <span class="close cursor" onclick="closeModal()">&times;</span>
  <div class="modal-content">

    <div class="mySlides">
      <div class="numbertext">1 / 4</div>
      <img src="assets/images/slider/slider_1.jpg" style="width:100%">
    </div>

    <div class="mySlides">
      <div class="numbertext">2 / 4</div>
      <img src="assets/images/slider/slider_1.jpg" style="width:100%">
    </div>

    <div class="mySlides">
      <div class="numbertext">3 / 4</div>
      <img src="assets/images/slider/slider_1.jpg" style="width:100%">
    </div>

    <div class="mySlides">
      <div class="numbertext">4 / 4</div>
      <img src="assets/images/slider/slider_1.jpg" style="width:100%">
    </div>

    < Next/previous controls>
    <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
    <a class="next" onclick="plusSlides(1)">&#10095;</a>

    <!-- Caption text >
    <div class="caption-container">
      <p id="caption"></p>
    </div>

    <!-- Thumbnail image controls >
    <div class="column">
      <img class="demo" src="img1.jpg" onclick="currentSlide(1)" alt="Nature">
    </div>

    <div class="column">
      <img class="demo" src="img2.jpg" onclick="currentSlide(2)" alt="Snow">
    </div>

    <div class="column">
      <img class="demo" src="img3.jpg" onclick="currentSlide(3)" alt="Mountains">
    </div>

    <div class="column">
      <img class="demo" src="img4.jpg" onclick="currentSlide(4)" alt="Lights">
    </div>
  </div>
</div>
  





    

    
    
  
    
    <!--  ************************* About Us Starts Here ************************** -->
        
    <section id="about_us" class="about-us">
        <div class="row no-margin">
            <div class="col-sm-6 image-bg no-padding">
                
            </div>
            <div class="col-sm-6 abut-yoiu">
                <h3>About Our Hospital</h3>
            <?php
            $ret=mysqli_query($con,"select * from tblpage where PageType='aboutus' ");
            while ($row=mysqli_fetch_array($ret)) {
            ?>

                <p><?php  echo $row['PageDescription'];?>.</p><?php } ?>
                        </div>
                    </div>
    </section>    
    
    
    <!-- ################# Footer Starts Here#######################--->

    <section id="contact_us" class="contact-us-single">

    <footer class="footer">
        <div class="container">
            <div class="row">
       
                <div class="col-md-6 col-sm-12">
                    <h2>Useful Links</h2>
                    <ul class="list-unstyled link-list">
                        <li><a ui-sref="about" href="#about_us">About us</a><i class="fa fa-angle-right"></i></li>
                        <li><a ui-sref="portfolio" href="#specialities">Specialities</a><i class="fa fa-angle-right"></i></li>
                        <li><a ui-sref="products" href="#logins">Logins</a><i class="fa fa-angle-right"></i></li>
                        <li><a ui-sref="contact" href="#">Contact us</a><i class="fa fa-angle-right"></i></li>
                    </ul>
                </div>
                <div class="col-md-6 col-sm-12 map-img">
                    <h2>Contact Us</h2>
                    <address class="md-margin-bottom-40">

<?php
$ret=mysqli_query($con,"select * from tblpage where PageType='contactus' ");
while ($row=mysqli_fetch_array($ret)) {
?>


                        <?php  echo $row['PageDescription'];?> <br>
                        Phone: <?php  echo $row['MobileNumber'];?> <br>
                        Email: <a href="mailto:<?php  echo $row['Email'];?>" class=""><?php  echo $row['Email'];?></a><br>
                        Timing: <?php  echo $row['OpenningTime'];?>
                    </address>

        <?php } ?>





                </div>
            </div>
        </div>
        

    </footer>
</section>


    <div class="copy">
            <div class="container">
         Hospital Management System
                
     
            </div>

        </div>
    
    </body>

<script src="assets/js/jquery-3.2.1.min.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/plugins/scroll-nav/js/jquery.easing.min.js"></script>
<script src="assets/plugins/scroll-nav/js/scrolling-nav.js"></script>
<script src="assets/plugins/scroll-fixed/jquery-scrolltofixed-min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
// Slideshows
<script>
var slideIndex = 1;

function plusDivs(n) {
slideIndex = slideIndex + n;
showDivs(slideIndex);
}

function showDivs(n) {
  var x = document.getElementsByClassName("mySlides");
  if (n > x.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = x.length} ;
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  x[slideIndex-1].style.display = "block";  
}

showDivs(1);
</script>
<script src="assets/js/script.js"></script>



</html>