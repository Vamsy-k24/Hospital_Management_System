<?php
session_start();
error_reporting(0);
include('include/config.php');
if(strlen($_SESSION['id']==0)) {
 header('location:logout.php');
  } else{

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Doctor  | Dashboard</title>

		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<link href="assets/vendor/fontawesome/css/fontawesome.min.css" rel="stylesheet">
		<link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
		<link href="assets/vendor/fontawesome/css/solid.min.css" rel="stylesheet">
		<link href="assets/vendor/fontawesome/css/brands.min.css" rel="stylesheet">
		<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
		<link href="assets/css/master.css" rel="stylesheet">
		<link href="assets/vendor/flagiconcss/css/flag-icon.min.css" rel="stylesheet">

	</head>
	<body>
		<div class="wrapper">		
		<?php include('include/sidebar.php');?>
						
		<?php include('include/header.php');?>
						
				<!-- end: TOP NAVBAR -->
				<div class="main-content" style="padding-bottom: 50px;">
					<div class="wrap-content container" id="container">
						<!-- start: PAGE TITLE -->
						<section id="page-title" style="padding: 15px;">
							<div class="row" style="text-align: right;">
								<div class="col-sm-8" style="padding: 15px;">
									<h2 class="mainTitle">Doctor | Dashboard</h2>
																	</div>
							</div>
						</section>
						<!-- end: PAGE TITLE -->
						<!-- start: BASIC EXAMPLE -->
							<div class="container-fluid container-fullw">
							<div class="row" style="padding: 5px;">
								<div class="col-sm-4" style="padding: 5px;">
									<div class="panel panel-white no-radius text-center">
										<div class="panel-body">
											<span class="fa-stack fa-2x"> <i class="fa fa-user fa-stack-2x text-primary"></i> <!--i class="fa fa-smile-o fa-stack-1x fa-inverse"></i--> </span>
											<h2 class="StepTitle">My Profile</h2>
											
											<p class="links cl-effect-1">
												<a href="edit-profile.php" style="color: blue;">
													-> Update Profile
												</a>
											</p>
										</div>
									</div>
								</div>
								<div class="col-sm-4" style="padding: 5px;">
									<div class="panel panel-white no-radius text-center">
										<div class="panel-body">
											<span class="fa-stack fa-2x"> <i class="fa fa-id-card fa-stack-2x text-primary"></i> <!--i class="fa fa-paperclip fa-stack-1x fa-inverse"></i--> </span>
											<h2 class="StepTitle">My Appointments</h2>
										
											<p class="cl-effect-1">
												<a href="appointment-history.php" style="color: blue;">
													-> View Appointment History
												</a>
											</p>
										</div>
									</div>
								</div>

								<div class="col-sm-4" style="padding: 5px;">
									<div class="panel panel-white no-radius text-center">
										<div class="panel-body">
											<span class="fa-stack fa-2x"> <i class="fa fa-file-alt fa-stack-2x text-primary"></i> <!--i class="fa fa-paperclip fa-stack-1x fa-inverse"></i--> </span>
											<h2 class="StepTitle">Manage Patients</h2>
										
											<p class="cl-effect-1">
												<a href="manage-patient.php" style="color: blue;">
													-> Manage
												</a>
											</p>
										</div>
									</div>
								</div>

								<div class="col-sm-4" style="padding: 5px;">
									<div class="panel panel-white no-radius text-center">
										<div class="panel-body">
											<span class="fa-stack fa-2x"> <i class="fa fa-search fa-stack-2x text-primary"></i> <!--i class="fa fa-paperclip fa-stack-1x fa-inverse"></i--> </span>
											<h2 class="StepTitle">Search Patients Info</h2>
										
											<p class="cl-effect-1">
												<a href="search.php" style="color: blue;">
													-> Search
												</a>
											</p>
										</div>
									</div>
								</div>
								
							</div>
						</div>
			
					
					
						
						
					
						<!-- end: SELECT BOXES -->
						
					</div>
				</div>
			</div>
			
		</div>
		<!-- start: MAIN JAVASCRIPTS -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
		<script src="vendor/autosize/autosize.min.js"></script>
		<script src="vendor/selectFx/classie.js"></script>
		<script src="vendor/selectFx/selectFx.js"></script>
		<script src="vendor/select2/select2.min.js"></script>
		<script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="assets/js/form-elements.js"></script>
		<script>
			jQuery(document).ready(function() {
				Main.init();
				FormElements.init();
			});
		</script>

		<script src="assets/js/form-elements.js"></script>
		<script src="assets/vendor/jquery/jquery.min.js"></script>
		<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
		<script src="assets/vendor/chartsjs/Chart.min.js"></script>
		<script src="assets/js/dashboard-charts.js"></script>
		<script src="assets/js/script.js"></script>

		<!-- end: JavaScript Event Handlers for this page -->
		<!-- end: CLIP-TWO JAVASCRIPTS -->
	</body>
</html>
<?php } ?>
