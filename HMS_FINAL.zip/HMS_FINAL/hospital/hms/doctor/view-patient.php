<?php
session_start();
error_reporting(0);
include('include/config.php');
if(strlen($_SESSION['id']==0)) {
 header('location:logout.php');
  } else{
if(isset($_POST['submit']))
  {
    
    $vid=$_GET['viewid'];
    // $mid=$_POST['mid'];
    $dname=$_POST['dname'];
    $bp=$_POST['bp'];
    $bs=$_POST['bs'];
    $weight=$_POST['weight'];
    $temp=$_POST['temp'];
   $pres=$_POST['pres'];
   
 
      $query.=mysqli_query($con, "insert tblmedicalhistory(PatientID,dname,BloodPressure,BloodSugar,Weight,Temperature,MedicalPres)value('$vid','$dname','$bp','$bs','$weight','$temp','$pres')");
    if ($query) {
    echo '<script>alert("Medicle history has been added.")</script>';
    echo "<script>window.location.href ='manage-patient.php'</script>";
  }
  else
    {
      echo '<script>alert("Something Went Wrong. Please try again")</script>';
    }

  
}

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Doctor | Manage Patients</title>
		
    <meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<link href="assets/vendor/fontawesome/css/fontawesome.min.css" rel="stylesheet">
		<link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
		<link href="assets/vendor/fontawesome/css/solid.min.css" rel="stylesheet">
		<link href="assets/vendor/fontawesome/css/brands.min.css" rel="stylesheet">
		<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
		<link href="assets/css/master.css" rel="stylesheet">
		<link href="assets/vendor/flagiconcss/css/flag-icon.min.css" rel="stylesheet">
	</head>
	<body>
  <div class="wrapper">		
		<?php include('include/sidebar.php');?>
						
		<?php include('include/header.php');?>
<div class="main-content" style="padding-bottom: 50px;">
<div class="wrap-content container" id="container">
						<!-- start: PAGE TITLE -->
<section id="page-title" style="padding: 15px;">
<div class="row">
<div class="col-sm-8" style="padding: 15px;">
<h2 class="mainTitle">Doctor | Manage Patients</h2>
</div>
</div>
</section>
<div class="container-fluid container-fullw bg-white" style="border: 2px solid #208688; border-radius: 5px; padding: 25px;">
<div class="row">
<div class="col-md-12">
<h5 class="over-title margin-bottom-15">Manage <span class="text-bold">Patients</span></h5>
<?php
                               $vid=$_GET['viewid'];
                               $ret=mysqli_query($con,"select * from tblpatient where ID='$vid'");
$cnt=1;
while ($row=mysqli_fetch_array($ret)) {
                               ?>
<table class="table table-bordered" style="border: 2px solid #000; border-radius: 5px; padding: 15px;">
 <tr align="center">
 <th colspan="12" style="font-size:20px;color:blue">Patient details</th> 
</tr>

    <tr>
    <th scope>Patient Name</th>
    <td><?php  echo $row['PatientName'];?></td>
    <th scope>Patient Email</th>
    <td><?php  echo $row['PatientEmail'];?></td>
  </tr>
  <tr>
    <th scope>Patient Mobile Number</th>
    <td><?php  echo $row['PatientContno'];?></td>
    <th>Patient Address</th>
    <td><?php  echo $row['PatientAdd'];?></td>
  </tr>
    <tr>
    <th>Patient Gender</th>
    <td><?php  echo $row['PatientGender'];?></td>
    <th>Patient Age</th>
    <td><?php  echo $row['PatientAge'];?></td>
  </tr>
  <tr>
    
    <th>Patient Medical History(if any)</th>
    <td><?php  echo $row['PatientMedhis'];?></td>
     <th>Patient Reg Date</th>
    <td><?php  echo $row['CreationDate'];?></td>
  </tr>
 
<?php }?>
</table>
<?php  

$ret=mysqli_query($con,"select * from tblmedicalhistory as tmh  where tmh.PatientID='$vid'");



 ?>
<table id="datatable" class="table table-bordered dt-responsive nowrap" style="border: 2px solid #000; border-radius: 5px; padding: 50px;">
  <tr align="center">
   <th colspan="12" style="font-size:20px;color:blue">Medical History</th> 
  </tr>
  <tr>
    <th>#</th>
    <th>MID</th>   
    <th>Doctor Name</th>  
<th>Blood Pressure</th>
<th>Weight</th>
<th>Blood Sugar</th>
<th>Body Temprature</th>
<th>Medical Prescription</th>
<th>Visit Date</th>
</tr>
<?php  
while ($row=mysqli_fetch_array($ret)) { 
  ?>
<tr>
  <td><?php echo $cnt;?></td>
  <td><?php  echo $row['ID'];?></td> 
  <td><?php  echo $row['dname'];?></td> 
 <td><?php  echo $row['BloodPressure'];?></td>
 <td><?php  echo $row['Weight'];?></td>
 <td><?php  echo $row['BloodSugar'];?></td> 
  <td><?php  echo $row['Temperature'];?></td>
  <td><?php  echo $row['MedicalPres'];?></td>
  <td><?php  echo $row['CreationDate'];?></td> 
</tr>
<?php $cnt=$cnt+1;} ?>
</table>

<p align="center">                            
  <button class="btn btn-primary waves-effect waves-light w-lg" data-bs-toggle="modal" data-bs-target="#myModal">Add Medical History</button>
</p>  

<?php  ?>
                                        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                          <div class="modal-dialog" role="document">
                                              <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Add Medical History</h5>
                                                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                  <table class="table table-bordered table-hover data-tables">

                                                    <form method="post" name="submit">
                                                      <!--tr>
                                                        <th>MID :
                                                        </th>
                                                        <td>
                                                          <input name="mid" placeholder="MID" class="form-control wd-450" required="true">
                                                        </td>
                                                      </tr-->    
                                                      <tr>
                                                      <th>Doctor Name :</th>
                                                      <td>
                                                      <input name="dname" placeholder="dname" class="form-control wd-450" required="true"></td>
                                                    </tr>  
                                                        <tr>
                                                      <th>Blood Pressure :</th>
                                                      <td>
                                                      <input name="bp" placeholder="Blood Pressure" class="form-control wd-450" required="true"></td>
                                                    </tr>                          
                                                      <tr>
                                                      <th>Blood Sugar :</th>
                                                      <td>
                                                      <input name="bs" placeholder="Blood Sugar" class="form-control wd-450" required="true"></td>
                                                    </tr> 
                                                    <tr>
                                                      <th>Weight :</th>
                                                      <td>
                                                      <input name="weight" placeholder="Weight" class="form-control wd-450" required="true"></td>
                                                    </tr>
                                                    <tr>
                                                      <th>Body Temprature :</th>
                                                      <td>
                                                      <input name="temp" placeholder="Body Temperature" class="form-control wd-450" required="true"></td>
                                                    </tr>
                                                                          
                                                      <tr>
                                                      <th>Prescription :</th>
                                                      <td>
                                                      <textarea name="pres" placeholder="Medical Prescription" rows="12" cols="14" class="form-control wd-450" required="true"></textarea></td>
                                                    </tr>  
                                                    
                                                  </table>
                                                </div>
                                                <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                                                  
                                                  
                                                </div>

                                                
</div>
</div></form>


</div>
</div>
<?php $ret=mysqli_query($con,"select * from tbltestresult  where PatientID='$vid' ");

                                                    //select * from tblmedicalhistory  where PatientID='$vid'

                                                    ?>
                                                    <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border: 2px solid #000; border-radius: 5px; padding: 15px; width: 100%;">
                                                      <tr align="center">
                                                      <th colspan="12" style="font-size:20px;color:blue">Test Results</th> 
                                                      </tr>
                                                      <tr>
                                                        <th>#</th>
                                                    <th>mhid</th>
                                                    <th>testresult</th>
                                                    <th>Visit Date</th>
                                                    </tr>
                                                    <?php  
                                                    while ($row=mysqli_fetch_array($ret)) { 
                                                      ?>
                                                    <tr>
                                                      <td><?php echo $cnt;?></td>
                                                    <td><?php  echo $row['MHID'];?></td>
                                                    <td><?php  echo $row['testresult'];?></td>
                                                      <td><?php  echo $row['CreationDate'];?></td> 
                                                    </tr>
                                                    <?php $cnt=$cnt+1;} ?>

                                                    </table>

                                                    <?php $ret=mysqli_query($con,"select * from images where patientid='$vid' ");

//select * from tblmedicalhistory  where PatientID='$vid'

 ?>
<table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
  <tr align="center">
   <th colspan="100" >Images</th> 
  </tr>
  <tr>
    <th>#</th>
<th>mhid</th>
<th>Images</th>
<th>Upload date</th>
</tr>
<?php  
$cnt=1;
while ($row=mysqli_fetch_array($ret)) { 
  ?>
<tr>
  <td><?php echo $cnt;?></td>
 <td><?php  echo $row['MHID'];?></td>
 <td><img src="<?php echo '../patient/assets/images/'.$row['file_name']; ?>" alt="" /></td>
  <td><?php  echo $row['CreationDate'];?></td> 
</tr>
<?php $cnt=$cnt+1;} ?>
</table>

</div>
</div>
</div>
			
		</div>
		<!-- start: MAIN JAVASCRIPTS -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
		<script src="vendor/autosize/autosize.min.js"></script>
		<script src="vendor/selectFx/classie.js"></script>
		<script src="vendor/selectFx/selectFx.js"></script>
		<script src="vendor/select2/select2.min.js"></script>
		<script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="assets/js/form-elements.js"></script>
		<script>
			jQuery(document).ready(function() {
				Main.init();
				FormElements.init();
			});
		</script>
		<!-- end: JavaScript Event Handlers for this page -->
		<!-- end: CLIP-TWO JAVASCRIPTS -->

    <script src="assets/js/form-elements.js"></script>
		<script src="assets/vendor/jquery/jquery.min.js"></script>
		<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
		<script src="assets/vendor/chartsjs/Chart.min.js"></script>
		<script src="assets/js/dashboard-charts.js"></script>
		<script src="assets/js/script.js"></script>

    
	</body>
</html>
<?php }  ?>
